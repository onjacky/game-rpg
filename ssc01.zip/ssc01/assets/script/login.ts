import mydb from "./mydb";


const { ccclass, property } = cc._decorator;
const smydb = new mydb();
@ccclass
export default class login extends cc.Component {

    @property(cc.Node)
    cuowuwind: cc.Node = null;
    @property(cc.Label)
    cuowulabel: cc.Label = null;

    @property(cc.EditBox)
    acctext: cc.EditBox = null;
    @property(cc.EditBox)
    passtext: cc.EditBox = null;



    onLoad() {
        this.LoginResults();
    }

    start() {

    }

    update(dt) {

    }

    youkedenglu() {
        mydb.myacc = "游客";
        cc.director.loadScene("index");
    }

    zhanghaodenglu() {
        
        let data = {   //创建一个JSON消息对象
            type: "login",
            data: {
                acc: this.acctext.string,
                pass: this.passtext.string
            }
        }
        mydb.ws.send(JSON.stringify(data));  //发送消息给服务器

    }

    LoginResults() {
        mydb.ws.onmessage = function (result) {
            let message = JSON.parse(result.data)
            switch (message.data) {
                case -1:
                    this.cuowuwind.active = true;
                    this.cuowulabel.string = "密码错误"
                    break;
                case 0:
                    this.cuowuwind.active = true;
                    this.cuowulabel.string = "账号错误"
                    break;
                case 1:
                    mydb.myacc = this.acctext.string;
                    cc.director.loadScene("index");
                    break;

                default:
                    break;
            }
            // console.log("收到消息11：", message.data);
        }.bind(this)
    }

    CloseTheWindow() {
        if (this.cuowuwind.active) {
            this.cuowuwind.active = false;
        }
    }
}
