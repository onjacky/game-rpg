

const { ccclass, property } = cc._decorator;

@ccclass
export default class NewClass extends cc.Component {

    @property(cc.Node)
    tishiwind: cc.Node = null;


    onLoad() {

    }

    start() {

    }

    update(dt) {

    }

    zhongjiangchakan() {
        cc.director.loadScene("jilu");
    }

    kongjianzhanbut() {
        cc.director.loadScene("zhuihao");
    }

    jinruhuodng() {
        cc.director.loadScene("huodong");
    }

    jiaoyijilu() {
        cc.director.loadScene("jiaoyijilu");
    }

    chongzhibut() {
        cc.director.loadScene("chongzhi");
    }

    tixianbut() {
        cc.director.loadScene("tixian");
    }

    tishixinxi() {
        if (this.tishiwind.active) {
            this.tishiwind.active = false;
        }
        else {
            this.tishiwind.active = true;
        }        
    }

    fanhuishouye() {
        cc.director.loadScene("login");
    }

}
