const { ccclass, property } = cc._decorator;

@ccclass
export default class index extends cc.Component {

    @property(cc.Sprite)
    beijingS: cc.Sprite = null;  //首页顶部图片组件

    @property(cc.SpriteFrame)
    qiehuantuS: cc.SpriteFrame[] = [];  //用于切换的图片数组



    qiehuanshu: number = 0;  //切换图片计数

    // LIFE-CYCLE CALLBACKS:

    onLoad() {
        this.qiehuanshu = 0;   //初始化切换计数
        //每3秒进行一次图片切换
        this.schedule(function () {
            this.qiehuantupian();
        }, 3);
    }

    start() {

    }

    update(dt) {


    }

    // 切换首页图片
    qiehuantupian() {
        if (this.qiehuanshu > 2) {
            this.qiehuanshu = 0;
        }
        this.beijingS.spriteFrame = this.qiehuantuS[this.qiehuanshu];
        this.qiehuanshu++;
    }

    // 进入分分彩
    jinrufenfencai() {
        cc.director.loadScene("ffc");
    }

    jinrudating() {
        cc.director.loadScene("dating");
    }

    jinruhuodong() {
        cc.director.loadScene("huodong");
    }

    jinrujilu() {
        cc.director.loadScene("jilu");
    }

    jinruwode() {
        cc.director.loadScene("wode");
    }

    jinrushouye() {
        cc.director.loadScene("index");
    }
}
