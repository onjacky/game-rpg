import mydb from "./mydb";

const { ccclass, property } = cc._decorator;

@ccclass
export default class NewClass extends cc.Component {

    @property(cc.Label)
    myname: cc.Label = null;

    @property(cc.Label)
    myjinbi: cc.Label = null;


    onLoad() {
        this.myname.string = mydb.myacc;
        if (mydb.myacc == "游客") {
            this.myjinbi.string = "1000";
        }
        else {
            this.myjinbi.string = String(mydb.mysum);
        }
    }

    start() {
        

    }

    update(dt) {

    }

    chongzhiyemian() {
        cc.director.loadScene("chongzhi");
    }
}
