// Learn TypeScript:
//  - https://docs.cocos.com/creator/manual/en/scripting/typescript.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html

import xiazhu from "./xiazhu";

const { ccclass, property } = cc._decorator;

@ccclass
export default class NewClass extends cc.Component {

    @property(cc.Label)
    haoma: cc.Label[] = [];

    @property(cc.Label)
    xiaoshi: cc.Label = null;
    @property(cc.Label)
    fenzhong: cc.Label = null;
    @property(cc.Label)
    miaozhong: cc.Label = null;


    @property(cc.Label)
    xianzaiqihao: cc.Label = null;
    @property(cc.Label)
    xiayiqihao: cc.Label = null;

    @property(cc.Label)
    kaijiangqihao: cc.Label = null;

    // @property
    // text: string = 'hello';

    // LIFE-CYCLE CALLBACKS:

    kaijiangzt: boolean = false;
    jisuanjieguo: boolean = true;

    onLoad() {
        this.kaijiangzt = false;
        this.jisuanjieguo = true;
        this.shujugengxin();

    }

    start() {
        this.suijikaijiang();
    }

    update(dt) {

        let myDate = new Date();
        if (myDate.getSeconds() < 10) {
            this.kaijiangzt = true;
        }
        else {
            this.kaijiangzt = false;
        }

        this.shujugengxin();
        this.suijikaijiang();

    }

    suijikaijiang() {
        if (this.kaijiangzt) {
            for (let i = 0; i < this.haoma.length; i++) {
                this.haoma[i].string = String(Math.floor(Math.random() * 10));
            }
            this.jisuanjieguo = true;
        }
        else if (this.jisuanjieguo) {
            let myDate = new Date();
            let lingshishu: number[] = [];
            lingshishu[0] = Math.floor((Number(this.xianzaiqihao.string) ^ -850761.9)) * 9 % 10 * -1;
            lingshishu[1] = Math.floor((Number(this.xianzaiqihao.string) ^ -254195.5)) * 8 % 10 * -1;
            lingshishu[2] = Math.floor((Number(this.xianzaiqihao.string) ^ -658412.7)) * 7 % 10 * -1;
            lingshishu[3] = Math.floor((Number(this.xianzaiqihao.string) ^ -715622.1)) * 6 % 10 * -1;
            lingshishu[4] = Math.floor((Number(this.xianzaiqihao.string) ^ -905214.6)) * 5 % 10 * -1;

            let lingshihezhi = 0;

            for (let i = 0; i < lingshishu.length; i++) {
                lingshihezhi += lingshishu[i];
            }

            for (let i = 0; i < lingshihezhi % 10; i++) {
                for (let k = 0; k < lingshishu.length; k++) {
                    lingshishu[i] *= lingshishu[i] + 3;
                }
                lingshishu[i] = lingshishu[i] % 10;
            }

            for (let i = 0; i < this.haoma.length; i++) {
                this.haoma[i].string = String(lingshishu[i]);
            }
            cc.log(lingshishu[0], lingshishu[1], lingshishu[2], lingshishu[3], lingshishu[4]);
            this.jisuanjieguo = false;
        }
    }

    shujugengxin() {
        let myDate = new Date();
        let mymiaozhong = 60 - myDate.getSeconds();
        let mymiaozhongst = String(mymiaozhong);
        if (mymiaozhong < 10) {
            mymiaozhongst = "0" + mymiaozhongst;
        }
        this.miaozhong.string = mymiaozhongst;

        let mynian = String(myDate.getFullYear());
        let myyue = myDate.getMonth() < 9 ? "0" + String(myDate.getMonth() + 1) : String(myDate.getMonth() + 1);
        let myri = myDate.getDate() < 10 ? "0" + String(myDate.getDate()) : String(myDate.getDate());
        let myshi = myDate.getHours() < 10 ? "0" + String(myDate.getHours()) : String(myDate.getHours());
        let myfen = myDate.getMinutes() < 10 ? "0" + String(myDate.getMinutes()) : String(myDate.getMinutes());
        let myshifen = ""
        if ((Number(myshi) * 60 + Number(myfen)) < 1000) {
            if ((Number(myshi) * 60 + Number(myfen)) < 100) {
                myshifen = "00" + String(Number(myshi) * 60 + Number(myfen));
            }
            else {
                myshifen = "0" + String(Number(myshi) * 60 + Number(myfen));
            }

        }

        this.xianzaiqihao.string = mynian + myyue + myri + myshifen;
        this.xiayiqihao.string = String(Number(this.xianzaiqihao.string) + 1);

        xiazhu.qihao = this.xianzaiqihao.string;
    }
}
