const {ccclass, property} = cc._decorator;

@ccclass
    export default  class mydb  {
    static ws = new WebSocket("ws://154.91.196.100:9977");
    static myacc = "";
    static mysum = 0;
    constructor() {
        mydb.ws.onopen = function (result) {
            console.log("链接服务器：", result);
        //     let data = {   //创建一个JSON消息对象
        //         type: "login",
        //         data: {
        //             acc: "test01"
        //         }
        //     }
        //    mydb.ws.send(JSON.stringify(data));  //发送消息给服务器
        }

        // 收到服务器消息
        mydb.ws.onmessage = function (result) {
            console.log("收到消息：", result.data);
        }

        // 错误信息
        mydb.ws.onerror = function (result) {
            console.log("错误信息：", result);
        }
        
    }
}
