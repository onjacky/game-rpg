// Learn TypeScript:
//  - https://docs.cocos.com/creator/manual/en/scripting/typescript.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html

import xiazhu from "./xiazhu";

const { ccclass, property } = cc._decorator;

@ccclass
export default class bianse extends cc.Component {

    @property(cc.Sprite)
    Sprite: cc.Sprite = null;

    @property(cc.SpriteFrame)
    SpriteFrame: cc.SpriteFrame[] = [];



    onLoad() {

    }

    start() {

    }

    update(dt) {

    }

    qiehuantupian() {
        if (this.Sprite.spriteFrame == this.SpriteFrame[0]) {
            this.Sprite.spriteFrame = this.SpriteFrame[1]
        }
        else {
            this.Sprite.spriteFrame = this.SpriteFrame[0]
        }

        xiazhu.zongxiazhu += xiazhu.xiazhujin;
        
        switch (this.node.getParent().name) {
            case "diyiqiu":
                xiazhu.xiazhuneirong += "第一球："
                break;
            case "dierqiu":
                xiazhu.xiazhuneirong += "第二球："
                break;
            case "disanqiu":
                xiazhu.xiazhuneirong += "第三球："
                break;
            case "disiqiu":
                xiazhu.xiazhuneirong += "第四球："
                break;
            case "diwuqiu":
                xiazhu.xiazhuneirong += "第五球："
                break;
            case "zonghe":
                xiazhu.xiazhuneirong += "总和："
                break;
            default:
                break;
        }


        switch (this.node.name) {
            case "xiazhu-da":
                xiazhu.xiazhuneirong += " 大  " + "注数：1 金额：" + xiazhu.xiazhujin + ".00\n"
                break;
            case "xiazhu-xiao":
                xiazhu.xiazhuneirong += " 小  " + "注数：1 金额：" + xiazhu.xiazhujin + ".00\n"
                break;
            case "xiazhu-dan":
                xiazhu.xiazhuneirong += " 单  " + "注数：1 金额：" + xiazhu.xiazhujin + ".00\n"
                break;
            case "xiazhu-shuang":
                xiazhu.xiazhuneirong += " 双  " + "注数：1 金额：" + xiazhu.xiazhujin + ".00\n"
                break;
            default:
                break;
        }

        cc.log(xiazhu.zongxiazhu);
        cc.log(this.node.name);
        cc.log(xiazhu.xiazhuneirong);
    }
}
