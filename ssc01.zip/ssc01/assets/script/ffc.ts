// Learn TypeScript:
//  - https://docs.cocos.com/creator/manual/en/scripting/typescript.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html

import xiazhu from "./xiazhu";

const { ccclass, property } = cc._decorator;

@ccclass
export default class ffc extends cc.Component {


    @property(cc.Sprite)
    xiazhubut: cc.Sprite[] = [];

    @property(cc.SpriteFrame)
    yuanshitupian: cc.SpriteFrame = null;

    @property(cc.Label)
    xiazhujinshu: cc.Label[] = [];

    @property(cc.Label)
    xianzaishu: cc.Label = null;

    @property(cc.Label)
    xiazhuneiorng: cc.Label = null;

    @property(cc.Node)
    quedingwind: cc.Node = null;

    @property(cc.Label)
    zongjineshu: cc.Label = null;

    @property(cc.Sprite)
    xialabut: cc.Sprite = null;

    @property(cc.SpriteFrame)
    xialatupian: cc.SpriteFrame[] = [];

    @property(cc.Node)
    lishinode: cc.Node = null;

    @property(cc.Label)
    lisiqihao: cc.Label[] = [];

    @property(cc.Label)
    lishihaoma: cc.Label[] = [];

    @property(cc.Label)
    xianzaiqihao: cc.Label = null;

    // @property
    // text: string = 'hello';


    onLoad() {
        xiazhu.xiazhujin = 10;
        xiazhu.zongxiazhu = 0;
        xiazhu.xiazhuneirong = "";
    }

    start() {

    }

    update(dt) {

    }
    // 清空下注
    qingkongxiazhu() {
        for (let i = 0; i < this.xiazhubut.length; i++) {
            this.xiazhubut[i].spriteFrame = this.yuanshitupian;
        }
        xiazhu.zongxiazhu = 0;
    }
    // 选择下注按钮
    xuanzaixiazhujin(event: any, zhujin: string) {
        if (zhujin == "quanbu") {
            zhujin = this.xianzaishu.string;
        }

        xiazhu.xiazhujin = Number(zhujin);
        this.xiazhujinshu[0].string = zhujin;
        this.xiazhujinshu[1].string = zhujin;

    }
    // 输入框数下注金额
    shuruxiazhujin() {
        if (Number(this.xiazhujinshu[1].string) < 10) {
            this.xiazhujinshu[0].string = "10";
            this.xiazhujinshu[1].string = "10";
        }
        xiazhu.xiazhujin = Number(this.xiazhujinshu[1].string);
    }
    // 确定下注
    quedingxiazhu() {
        if (this.quedingwind.active) {
            this.quedingwind.active = false;
        }
        else {
            this.quedingwind.active = true;
        }
        this.xianzaiqihao.string = xiazhu.qihao;
        this.xiazhuneiorng.string = xiazhu.xiazhuneirong;
        this.zongjineshu.string = String(xiazhu.zongxiazhu);

    }
    // 返回首页
    fanhuishouye() {
        cc.director.loadScene("index");
    }
    // 查看历史 下拉
    xialaanniu() {
        if (this.xialabut.spriteFrame == this.xialatupian[0]) {
            this.xialabut.spriteFrame = this.xialatupian[1]
            this.lishinode.active = true;
            this.lishishuju();
        }
        else {
            this.xialabut.spriteFrame = this.xialatupian[0]
            this.lishinode.active = false;
        }
    }

    lishishuju() {
        for (let i = 0; i < this.lisiqihao.length; i++) {
            this.lisiqihao[i].string = String(Number(xiazhu.qihao) - i);
            this.suijikaijiang(this.lisiqihao[i].string, i);
        }
    }

    suijikaijiang(xianzhiqihao: string, bianhao: number) {

        let lingshishu: number[] = [];
        lingshishu[0] = Math.floor((Number(xianzhiqihao) ^ -850761.9)) * 9 % 10 * -1;
        lingshishu[1] = Math.floor((Number(xianzhiqihao) ^ -254195.5)) * 8 % 10 * -1;
        lingshishu[2] = Math.floor((Number(xianzhiqihao) ^ -658412.7)) * 7 % 10 * -1;
        lingshishu[3] = Math.floor((Number(xianzhiqihao) ^ -715622.1)) * 6 % 10 * -1;
        lingshishu[4] = Math.floor((Number(xianzhiqihao) ^ -905214.6)) * 5 % 10 * -1;

        let lingshihezhi = 0;

        for (let i = 0; i < lingshishu.length; i++) {
            lingshihezhi += lingshishu[i];
        }

        for (let i = 0; i < lingshihezhi % 10; i++) {
            for (let k = 0; k < lingshishu.length; k++) {
                lingshishu[i] *= lingshishu[i] + 3;
            }
            lingshishu[i] = lingshishu[i] % 10;
        }
        this.lishihaoma[bianhao].string = "【"
        for (let i = 0; i < 5; i++) {
            this.lishihaoma[bianhao].string += " " + String(lingshishu[i]);
        }
        this.lishihaoma[bianhao].string += "】"

    }

    // 返回首页
    dianjizhuihao() {
        cc.director.loadScene("zhuihao");
    }

}
