// Learn TypeScript:
//  - https://docs.cocos.com/creator/manual/en/scripting/typescript.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html

const { ccclass, property } = cc._decorator;

@ccclass
export default class NewClass extends cc.Component {

    @property(cc.Label)
    jihuowenzi: cc.Label[] = [];

    @property(cc.Node)
    xuanzhebiao: cc.Node = null;

    @property(cc.Node)
    xiugaibiao: cc.Node = null;


    @property(cc.Node)
    test01: cc.Node = null;


    // @property
    // text: string = 'hello';

    // LIFE-CYCLE CALLBACKS:

    onLoad() {
        //  console.log(this.xuanzhebiao.active);
        // console.log(this.xiugaibiao.active);   
        // console.log(this.test01.active)
    }

    start() {

    }

    update(dt) {
        
    }

    yijianjihuo() {
        for (let i = 0; i < this.jihuowenzi.length; i++) {
            this.jihuowenzi[i].string = "已激活";
        }
    }

    yijianguanbi() {
        for (let i = 0; i < this.jihuowenzi.length; i++) {
            this.jihuowenzi[i].string = "未激活";
        }
    }

    // 返回首页
    fanhuishouye() {
        cc.director.loadScene("index");
    }

    xiugaibut() {
        if (!this.xiugaibiao.active) {
            this.xiugaibiao.active = true;
        }
        if (this.xuanzhebiao.active) {
            this.xuanzhebiao.active = false;
        }
        
    }

    xuanzhebut() {
        if (this.xiugaibiao.active) {
            this.xiugaibiao.active = false;
        }
        if (!this.xuanzhebiao.active) {
            this.xuanzhebiao.active = true;
        }
    }



    
}
