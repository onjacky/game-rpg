"use strict";
cc._RF.push(module, '36aaakRfUJM2LLPx3yr47Fu', 'mydb');
// script/mydb.ts

"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var mydb = /** @class */ (function () {
    function mydb() {
        mydb_1.ws.onopen = function (result) {
            console.log("链接服务器：", result);
            //     let data = {   //创建一个JSON消息对象
            //         type: "login",
            //         data: {
            //             acc: "test01"
            //         }
            //     }
            //    mydb.ws.send(JSON.stringify(data));  //发送消息给服务器
        };
        // 收到服务器消息
        mydb_1.ws.onmessage = function (result) {
            console.log("收到消息：", result.data);
        };
        // 错误信息
        mydb_1.ws.onerror = function (result) {
            console.log("错误信息：", result);
        };
    }
    mydb_1 = mydb;
    var mydb_1;
    mydb.ws = new WebSocket("ws://154.91.196.100:9977");
    mydb.myacc = "";
    mydb.mysum = 0;
    mydb = mydb_1 = __decorate([
        ccclass
    ], mydb);
    return mydb;
}());
exports.default = mydb;

cc._RF.pop();