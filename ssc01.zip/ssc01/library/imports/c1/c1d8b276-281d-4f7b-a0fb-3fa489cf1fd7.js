"use strict";
cc._RF.push(module, 'c1d8bJ2KB1Pe6D7P6SJzx/X', 'login');
// script/login.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var mydb_1 = require("./mydb");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var smydb = new mydb_1.default();
var login = /** @class */ (function (_super) {
    __extends(login, _super);
    function login() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.cuowuwind = null;
        _this.cuowulabel = null;
        _this.acctext = null;
        _this.passtext = null;
        return _this;
    }
    login.prototype.onLoad = function () {
        this.LoginResults();
    };
    login.prototype.start = function () {
    };
    login.prototype.update = function (dt) {
    };
    login.prototype.youkedenglu = function () {
        mydb_1.default.myacc = "游客";
        cc.director.loadScene("index");
    };
    login.prototype.zhanghaodenglu = function () {
        var data = {
            type: "login",
            data: {
                acc: this.acctext.string,
                pass: this.passtext.string
            }
        };
        mydb_1.default.ws.send(JSON.stringify(data)); //发送消息给服务器
    };
    login.prototype.LoginResults = function () {
        mydb_1.default.ws.onmessage = function (result) {
            var message = JSON.parse(result.data);
            switch (message.data) {
                case -1:
                    this.cuowuwind.active = true;
                    this.cuowulabel.string = "密码错误";
                    break;
                case 0:
                    this.cuowuwind.active = true;
                    this.cuowulabel.string = "账号错误";
                    break;
                case 1:
                    mydb_1.default.myacc = this.acctext.string;
                    cc.director.loadScene("index");
                    break;
                default:
                    break;
            }
            // console.log("收到消息11：", message.data);
        }.bind(this);
    };
    login.prototype.CloseTheWindow = function () {
        if (this.cuowuwind.active) {
            this.cuowuwind.active = false;
        }
    };
    __decorate([
        property(cc.Node)
    ], login.prototype, "cuowuwind", void 0);
    __decorate([
        property(cc.Label)
    ], login.prototype, "cuowulabel", void 0);
    __decorate([
        property(cc.EditBox)
    ], login.prototype, "acctext", void 0);
    __decorate([
        property(cc.EditBox)
    ], login.prototype, "passtext", void 0);
    login = __decorate([
        ccclass
    ], login);
    return login;
}(cc.Component));
exports.default = login;

cc._RF.pop();