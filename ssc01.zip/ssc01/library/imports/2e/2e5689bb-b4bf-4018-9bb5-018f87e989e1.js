"use strict";
cc._RF.push(module, '2e568m7tL9AGJu1AY+H6Ynh', 'index');
// script/index.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var index = /** @class */ (function (_super) {
    __extends(index, _super);
    function index() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.beijingS = null; //首页顶部图片组件
        _this.qiehuantuS = []; //用于切换的图片数组
        _this.qiehuanshu = 0; //切换图片计数
        return _this;
    }
    // LIFE-CYCLE CALLBACKS:
    index.prototype.onLoad = function () {
        this.qiehuanshu = 0; //初始化切换计数
        //每3秒进行一次图片切换
        this.schedule(function () {
            this.qiehuantupian();
        }, 3);
    };
    index.prototype.start = function () {
    };
    index.prototype.update = function (dt) {
    };
    // 切换首页图片
    index.prototype.qiehuantupian = function () {
        if (this.qiehuanshu > 2) {
            this.qiehuanshu = 0;
        }
        this.beijingS.spriteFrame = this.qiehuantuS[this.qiehuanshu];
        this.qiehuanshu++;
    };
    // 进入分分彩
    index.prototype.jinrufenfencai = function () {
        cc.director.loadScene("ffc");
    };
    index.prototype.jinrudating = function () {
        cc.director.loadScene("dating");
    };
    index.prototype.jinruhuodong = function () {
        cc.director.loadScene("huodong");
    };
    index.prototype.jinrujilu = function () {
        cc.director.loadScene("jilu");
    };
    index.prototype.jinruwode = function () {
        cc.director.loadScene("wode");
    };
    index.prototype.jinrushouye = function () {
        cc.director.loadScene("index");
    };
    __decorate([
        property(cc.Sprite)
    ], index.prototype, "beijingS", void 0);
    __decorate([
        property(cc.SpriteFrame)
    ], index.prototype, "qiehuantuS", void 0);
    index = __decorate([
        ccclass
    ], index);
    return index;
}(cc.Component));
exports.default = index;

cc._RF.pop();