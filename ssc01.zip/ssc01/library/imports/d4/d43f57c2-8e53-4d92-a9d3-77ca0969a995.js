"use strict";
cc._RF.push(module, 'd43f5fCjlNNkqnTd8oJaamV', 'bianse');
// script/bianse.ts

"use strict";
// Learn TypeScript:
//  - https://docs.cocos.com/creator/manual/en/scripting/typescript.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var xiazhu_1 = require("./xiazhu");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var bianse = /** @class */ (function (_super) {
    __extends(bianse, _super);
    function bianse() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.Sprite = null;
        _this.SpriteFrame = [];
        return _this;
    }
    bianse.prototype.onLoad = function () {
    };
    bianse.prototype.start = function () {
    };
    bianse.prototype.update = function (dt) {
    };
    bianse.prototype.qiehuantupian = function () {
        if (this.Sprite.spriteFrame == this.SpriteFrame[0]) {
            this.Sprite.spriteFrame = this.SpriteFrame[1];
        }
        else {
            this.Sprite.spriteFrame = this.SpriteFrame[0];
        }
        xiazhu_1.default.zongxiazhu += xiazhu_1.default.xiazhujin;
        switch (this.node.getParent().name) {
            case "diyiqiu":
                xiazhu_1.default.xiazhuneirong += "第一球：";
                break;
            case "dierqiu":
                xiazhu_1.default.xiazhuneirong += "第二球：";
                break;
            case "disanqiu":
                xiazhu_1.default.xiazhuneirong += "第三球：";
                break;
            case "disiqiu":
                xiazhu_1.default.xiazhuneirong += "第四球：";
                break;
            case "diwuqiu":
                xiazhu_1.default.xiazhuneirong += "第五球：";
                break;
            case "zonghe":
                xiazhu_1.default.xiazhuneirong += "总和：";
                break;
            default:
                break;
        }
        switch (this.node.name) {
            case "xiazhu-da":
                xiazhu_1.default.xiazhuneirong += " 大  " + "注数：1 金额：" + xiazhu_1.default.xiazhujin + ".00\n";
                break;
            case "xiazhu-xiao":
                xiazhu_1.default.xiazhuneirong += " 小  " + "注数：1 金额：" + xiazhu_1.default.xiazhujin + ".00\n";
                break;
            case "xiazhu-dan":
                xiazhu_1.default.xiazhuneirong += " 单  " + "注数：1 金额：" + xiazhu_1.default.xiazhujin + ".00\n";
                break;
            case "xiazhu-shuang":
                xiazhu_1.default.xiazhuneirong += " 双  " + "注数：1 金额：" + xiazhu_1.default.xiazhujin + ".00\n";
                break;
            default:
                break;
        }
        cc.log(xiazhu_1.default.zongxiazhu);
        cc.log(this.node.name);
        cc.log(xiazhu_1.default.xiazhuneirong);
    };
    __decorate([
        property(cc.Sprite)
    ], bianse.prototype, "Sprite", void 0);
    __decorate([
        property(cc.SpriteFrame)
    ], bianse.prototype, "SpriteFrame", void 0);
    bianse = __decorate([
        ccclass
    ], bianse);
    return bianse;
}(cc.Component));
exports.default = bianse;

cc._RF.pop();