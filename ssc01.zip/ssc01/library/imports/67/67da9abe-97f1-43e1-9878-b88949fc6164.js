"use strict";
cc._RF.push(module, '67da9q+l/FD4Zh4uIlJ/GFk', 'ffc');
// script/ffc.ts

"use strict";
// Learn TypeScript:
//  - https://docs.cocos.com/creator/manual/en/scripting/typescript.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var xiazhu_1 = require("./xiazhu");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var ffc = /** @class */ (function (_super) {
    __extends(ffc, _super);
    function ffc() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.xiazhubut = [];
        _this.yuanshitupian = null;
        _this.xiazhujinshu = [];
        _this.xianzaishu = null;
        _this.xiazhuneiorng = null;
        _this.quedingwind = null;
        _this.zongjineshu = null;
        _this.xialabut = null;
        _this.xialatupian = [];
        _this.lishinode = null;
        _this.lisiqihao = [];
        _this.lishihaoma = [];
        _this.xianzaiqihao = null;
        return _this;
    }
    // @property
    // text: string = 'hello';
    ffc.prototype.onLoad = function () {
        xiazhu_1.default.xiazhujin = 10;
        xiazhu_1.default.zongxiazhu = 0;
        xiazhu_1.default.xiazhuneirong = "";
    };
    ffc.prototype.start = function () {
    };
    ffc.prototype.update = function (dt) {
    };
    // 清空下注
    ffc.prototype.qingkongxiazhu = function () {
        for (var i = 0; i < this.xiazhubut.length; i++) {
            this.xiazhubut[i].spriteFrame = this.yuanshitupian;
        }
        xiazhu_1.default.zongxiazhu = 0;
    };
    // 选择下注按钮
    ffc.prototype.xuanzaixiazhujin = function (event, zhujin) {
        if (zhujin == "quanbu") {
            zhujin = this.xianzaishu.string;
        }
        xiazhu_1.default.xiazhujin = Number(zhujin);
        this.xiazhujinshu[0].string = zhujin;
        this.xiazhujinshu[1].string = zhujin;
    };
    // 输入框数下注金额
    ffc.prototype.shuruxiazhujin = function () {
        if (Number(this.xiazhujinshu[1].string) < 10) {
            this.xiazhujinshu[0].string = "10";
            this.xiazhujinshu[1].string = "10";
        }
        xiazhu_1.default.xiazhujin = Number(this.xiazhujinshu[1].string);
    };
    // 确定下注
    ffc.prototype.quedingxiazhu = function () {
        if (this.quedingwind.active) {
            this.quedingwind.active = false;
        }
        else {
            this.quedingwind.active = true;
        }
        this.xianzaiqihao.string = xiazhu_1.default.qihao;
        this.xiazhuneiorng.string = xiazhu_1.default.xiazhuneirong;
        this.zongjineshu.string = String(xiazhu_1.default.zongxiazhu);
    };
    // 返回首页
    ffc.prototype.fanhuishouye = function () {
        cc.director.loadScene("index");
    };
    // 查看历史 下拉
    ffc.prototype.xialaanniu = function () {
        if (this.xialabut.spriteFrame == this.xialatupian[0]) {
            this.xialabut.spriteFrame = this.xialatupian[1];
            this.lishinode.active = true;
            this.lishishuju();
        }
        else {
            this.xialabut.spriteFrame = this.xialatupian[0];
            this.lishinode.active = false;
        }
    };
    ffc.prototype.lishishuju = function () {
        for (var i = 0; i < this.lisiqihao.length; i++) {
            this.lisiqihao[i].string = String(Number(xiazhu_1.default.qihao) - i);
            this.suijikaijiang(this.lisiqihao[i].string, i);
        }
    };
    ffc.prototype.suijikaijiang = function (xianzhiqihao, bianhao) {
        var lingshishu = [];
        lingshishu[0] = Math.floor((Number(xianzhiqihao) ^ -850761.9)) * 9 % 10 * -1;
        lingshishu[1] = Math.floor((Number(xianzhiqihao) ^ -254195.5)) * 8 % 10 * -1;
        lingshishu[2] = Math.floor((Number(xianzhiqihao) ^ -658412.7)) * 7 % 10 * -1;
        lingshishu[3] = Math.floor((Number(xianzhiqihao) ^ -715622.1)) * 6 % 10 * -1;
        lingshishu[4] = Math.floor((Number(xianzhiqihao) ^ -905214.6)) * 5 % 10 * -1;
        var lingshihezhi = 0;
        for (var i = 0; i < lingshishu.length; i++) {
            lingshihezhi += lingshishu[i];
        }
        for (var i = 0; i < lingshihezhi % 10; i++) {
            for (var k = 0; k < lingshishu.length; k++) {
                lingshishu[i] *= lingshishu[i] + 3;
            }
            lingshishu[i] = lingshishu[i] % 10;
        }
        this.lishihaoma[bianhao].string = "【";
        for (var i = 0; i < 5; i++) {
            this.lishihaoma[bianhao].string += " " + String(lingshishu[i]);
        }
        this.lishihaoma[bianhao].string += "】";
    };
    // 返回首页
    ffc.prototype.dianjizhuihao = function () {
        cc.director.loadScene("zhuihao");
    };
    __decorate([
        property(cc.Sprite)
    ], ffc.prototype, "xiazhubut", void 0);
    __decorate([
        property(cc.SpriteFrame)
    ], ffc.prototype, "yuanshitupian", void 0);
    __decorate([
        property(cc.Label)
    ], ffc.prototype, "xiazhujinshu", void 0);
    __decorate([
        property(cc.Label)
    ], ffc.prototype, "xianzaishu", void 0);
    __decorate([
        property(cc.Label)
    ], ffc.prototype, "xiazhuneiorng", void 0);
    __decorate([
        property(cc.Node)
    ], ffc.prototype, "quedingwind", void 0);
    __decorate([
        property(cc.Label)
    ], ffc.prototype, "zongjineshu", void 0);
    __decorate([
        property(cc.Sprite)
    ], ffc.prototype, "xialabut", void 0);
    __decorate([
        property(cc.SpriteFrame)
    ], ffc.prototype, "xialatupian", void 0);
    __decorate([
        property(cc.Node)
    ], ffc.prototype, "lishinode", void 0);
    __decorate([
        property(cc.Label)
    ], ffc.prototype, "lisiqihao", void 0);
    __decorate([
        property(cc.Label)
    ], ffc.prototype, "lishihaoma", void 0);
    __decorate([
        property(cc.Label)
    ], ffc.prototype, "xianzaiqihao", void 0);
    ffc = __decorate([
        ccclass
    ], ffc);
    return ffc;
}(cc.Component));
exports.default = ffc;

cc._RF.pop();